﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POO_2
{
    internal class LineaVenta
    {
        private Producto Producto { get; set; }
        private int StockProducto { get; set; }

        internal MaquinaExpendedora MaquinaExpendedora
        {
            get => default;
            set
            {
            }
        }

        public Producto GetProducto()
        {
            return Producto;
        }
        public void SetProducto(Producto producto)
        {
            Producto= producto;
        }
        public int GetStockProducto()
        { 
            return StockProducto;
        }
        public void SetStockProducto(int stock)
        {
            if(stock >=0)
                StockProducto= stock;
            else StockProducto=0;
        }
        public LineaVenta() { }
        public LineaVenta(Producto producto, int stockProducto)
        {
            SetProducto(producto);
            SetStockProducto(stockProducto);
        }
    }
}
