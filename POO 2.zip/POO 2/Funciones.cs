﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POO_2
{
    internal class Funciones
    {
        public static string PedirNombre()
        {
            string nombre;
            Console.WriteLine("Introduce el nombre:");
            nombre = Console.ReadLine();
            while (nombre == "")
            {
                Console.WriteLine("Error, el nombre  no puede estar vacío. Vuelva a intentarlo:");
                nombre = Console.ReadLine();
            }
            return nombre;
        }
        public static decimal PedirDinero()
        {
            decimal dinero;
            Console.WriteLine("Introducir importe:");
            while (!decimal.TryParse(Console.ReadLine(), out dinero) || dinero < 0)
                Console.WriteLine("Error, el importe debe de ser un valor numérico positivo. Vuelva a intentarlo:");
            return dinero;
        }

        public static void MostrarMenu()
        {
            Console.Clear();
            Console.WriteLine("   -----   MENÚ   -----");
            Console.WriteLine("Elige una opción:");
            Console.WriteLine("1.- Comprar Producto");
            Console.WriteLine("2.- Rellenar máquina al completo");
            Console.WriteLine("3.- Introducir nuevo producto a la venta");
            Console.WriteLine("4.- Eliminar producto a la venta");
            Console.WriteLine("5.- Comprobar stock de la máquina");
            Console.WriteLine("6.- Salir");
        }
        public static void MostrarProductosDisponibles(MaquinaExpendedora maquina)
        {
            int cont=1;
            maquina.GetListaProductos().ForEach(producto => Console.WriteLine(cont + ".- " + producto.GetProducto().ToString()));
        }


    }
}
