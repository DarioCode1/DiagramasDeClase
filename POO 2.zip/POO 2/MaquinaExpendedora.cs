﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POO_2
{
    internal class MaquinaExpendedora
    {
        private const int LINEASVENTA = 5;  //20;
        private const int  PRODMAX= 5;  //10;
        private List<LineaVenta> ListaProductos { get; set; }
        private string NombreMaquina { set; get; }

        public MaquinaExpendedora() { }
        public MaquinaExpendedora(List<LineaVenta> listaProductos, string nombre)
        {
            ListaProductos=listaProductos;
            SetNombreMaquina(nombre);
        }
        public int GetLineasVenta()
        {
            return LINEASVENTA;
        }
        public int GetProdMax()
        {
            return PRODMAX;
        }
        public List<LineaVenta> GetListaProductos()
        {
            return ListaProductos;
        }
        public void SetListaProductos(List<LineaVenta> listaProductos)
        {
            ListaProductos = listaProductos;
        }
        public string GetNombreMaquina()
        {
            return NombreMaquina;
        }
        public void SetNombreMaquina(string nombre)
        {
            if (nombre.Length > 0) NombreMaquina = nombre;
            else NombreMaquina = "UNKNOWN NAME";
        }

        public static int PedirCantidad()
        {
            int cantidad;
            while (!int.TryParse(Console.ReadLine(), out cantidad) || cantidad < 0 || cantidad > PRODMAX)
                Console.WriteLine("Error, el precio introducido debe ser un valor numérico entero positivo, y el máximo son 10 productos por línea de venta. Vuelva a intentarlo:");
            return cantidad;
        }

        public void ComprarProducto()
        {
            decimal dineroCliente;
            decimal devolucion;
            int cont = 1;

            if (ListaProductos.Count > 0)
            {
                Console.WriteLine("Introduce el dinero:");
                dineroCliente = Funciones.PedirDinero();
                List<LineaVenta> asequibles = GetListaProductos().FindAll(producto => producto.GetProducto().GetPrecio() <= dineroCliente);
                if (asequibles.Count == 0)
                    Console.WriteLine("Lo siento, dinero insuficiente para cualquier producto.");
                else
                {
                    Console.WriteLine("Eston son los productos que puedes adquirir con ese dinero:");
                    asequibles.ForEach(producto => { Console.WriteLine((cont++) + ".- " + producto.GetProducto().ToString()); });
                    Console.WriteLine("Elija, tecleándo su número correspondiente, el producto que desea comprar:");
                    int option;
                    while (!int.TryParse(Console.ReadLine(), out option) || option < 1 || option > asequibles.Count)
                    Console.WriteLine("El número introducido no está en la lista, vuelva a intentarlo:");
                    LineaVenta elegido = ListaProductos.Find(producto => producto.GetProducto().GetNombre() == asequibles[option - 1].GetProducto().GetNombre());
                    elegido.SetStockProducto(elegido.GetStockProducto() - 1);
                    if (dineroCliente > elegido.GetProducto().GetPrecio())
                    {
                        devolucion = dineroCliente - elegido.GetProducto().GetPrecio();
                        Console.WriteLine("Vueltas: " + devolucion);
                    }
                    else
                        Console.WriteLine("Importe justo, gracias");
                }
            }
            else
                Console.WriteLine("Lo siento, la máquina no tiene lineas de venta disponibles.");
        }
        public  bool ComprobarLineasVacias()
        {
            bool vacia=false;
            if (ListaProductos==null)
            {
                vacia=true;
            }          
            return vacia;
        }
        public  void RellenarMaquina()
        {
            if (ListaProductos.Count==0)
                Console.WriteLine("Lo sentimos, la máquina expendedora no tiene registrado ningún producto");
            else
                ListaProductos.ForEach(producto => producto.SetStockProducto(PRODMAX));
        }
        public void IntroducirNuevoProductoVenta()
        {
            Producto producto = new Producto();
            LineaVenta lineaVenta = new LineaVenta();
            string nombre="";
            decimal precio = 0;
            int cantidad = 0;
            Console.Clear();
            Console.WriteLine("Introduce el nombre y el importe del nuevo producto:");
            nombre=Funciones.PedirNombre();
            producto.SetNombre(nombre);
            precio=Funciones.PedirDinero();
            producto.SetPrecio(precio);
            Console.WriteLine("Introduce el stock de productos que quieres colocar en la máquina(máximo 10)");
            cantidad=MaquinaExpendedora.PedirCantidad();
            lineaVenta.SetProducto(producto);
            lineaVenta.SetStockProducto(cantidad);
            if (ListaProductos == null) 
                ListaProductos=new List<LineaVenta> {lineaVenta};
            else
                ListaProductos.Add(lineaVenta);
        }    
        public void EliminarProductoVenta()
        {
            int option,cont=1;

            Console.WriteLine("Introduce el número de la línea de venta a eliminar");
            ListaProductos.ForEach(producto => { Console.WriteLine(cont + ".- " + producto.GetProducto().ToString());cont++; });
            while (!int.TryParse(Console.ReadLine(), out option) || option < 1 || option >ListaProductos.Count)
                Console.WriteLine("Lo siento, el dato introducido no corresponde con ninguna línea de venta, vuelva a probar:");
            ListaProductos.RemoveAt(option - 1);

        }
        public void VerStock()
        {
            ListaProductos.ForEach(producto => Console.WriteLine(producto.GetProducto().ToString()+" .............. Stock Disponible: "+producto.GetStockProducto()));
        }
    }
}
