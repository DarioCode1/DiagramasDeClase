﻿namespace POO_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int option1 = 0;
            string nombre = "";
            List<LineaVenta> listaProductos=new List<LineaVenta>();
            MaquinaExpendedora maquina= new MaquinaExpendedora();
            Console.WriteLine("Bienvenido a la maquina expendedora. \nIntroduce el nombre de la máquina con la que deseas trabajar:");
            maquina.SetNombreMaquina(Funciones.PedirNombre());
            do
            {
                Funciones.MostrarMenu();
                while (!int.TryParse(Console.ReadLine(), out option1) || option1 < 1 || option1 > 6)
                    Console.WriteLine("Lo siento, el valor introducido debe de ser entre 1 y 6. Vuelva a intentarlo:");
                switch (option1)
                {
                    case 1:
                        {
                            if (!maquina.ComprobarLineasVacias())
                            { 
                                maquina.ComprarProducto();
                                Console.WriteLine("Producto vendido");
                            }
                            else
                                Console.WriteLine("Lo siento, la máquina no tiene lineas de venta disponibles.");

                            Console.WriteLine("\nPulse una tecla para Continuar.");
                            Console.ReadKey();
                            break;
                        }
                    case 2:
                        {
                            if (maquina.GetListaProductos()!=null)
                            {
                                maquina.RellenarMaquina();
                                Console.WriteLine("Máquina rellenada.");
                            }
                            else
                                Console.WriteLine("Lo siento, la máquina no tiene lineas de venta disponibles.");

                            Console.WriteLine("Pulse una tecla para Continuar.");
                            Console.ReadKey();
                            break;
                        }
                    case 3:
                        {
                            if (maquina.GetListaProductos() == null)
                                maquina.IntroducirNuevoProductoVenta();
                            else
                            { 
                                if (maquina.GetListaProductos().Count < maquina.GetLineasVenta())
                                {
                                    maquina.IntroducirNuevoProductoVenta();
                                }
                                else
                                    Console.WriteLine("Lo siento, la máquina no tiene lineas de venta disponibles."); 
                            }
                            Console.WriteLine("\nPulse una tecla para Continuar.");
                            Console.ReadKey();
                            break;
                        }
                    case 4:
                        {
                            if(!maquina.ComprobarLineasVacias())
                                maquina.EliminarProductoVenta();
                            else
                                Console.WriteLine("Lo siento, la máquina no tiene lineas de venta disponibles.");
                            Console.WriteLine("\nPulse una tecla para Continuar.");
                            Console.ReadKey();
                            break;
                        }
                    case 5:
                        {
                            if (!maquina.ComprobarLineasVacias())
                                maquina.VerStock();
                            else
                                Console.WriteLine("Lo siento, la máquina no tiene lineas de venta disponibles.");

                            Console.WriteLine("Pulse una tecla para Continuar.");
                            Console.ReadKey();
                            break;
                        }
                    case 6:
                        {
                            Console.WriteLine("Gracais por usar nuestros servicios, pulse una tecla para salir.");
                            Console.ReadKey();
                            break;
                        }
                }
            } while (option1 != 6) ;
        }
    }
}