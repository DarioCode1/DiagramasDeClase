﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POO_2
{
    internal class Producto
    {
        private string Nombre { get; set; }
        private decimal Precio { get; set; }

        internal LineaVenta LineaVenta
        {
            get => default;
            set
            {
            }
        }

        public Producto()
        { }
        public Producto(string nombre, decimal precio)
        {
            SetNombre(nombre);
            SetPrecio(precio);
        }
        public void SetNombre(string nombre)
        {
            if (!string.IsNullOrEmpty(nombre)) Nombre = nombre;
            else Nombre = "Nombre desconocido";
        }
        public string GetNombre()
        {
            return Nombre;
        }
        public void SetPrecio(decimal precio)
        {
            if (precio >= 0) Precio = precio;
        }
        public decimal GetPrecio()
        {
            return Precio;
        }
        public override string ToString()
        {
            return "Producto:   " + Nombre + " ........... " + "Precio ............ " + Precio;
        }

    }
}
