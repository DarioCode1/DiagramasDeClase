﻿using System.Diagnostics.Contracts;

namespace Ejercicio2_Apartado3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<Contacto> listaContactos = new List<Contacto>();
            int opcion1 = 0;
            int menuOptions = 7;
            do
            {
                Funciones.MostrarMenu();
                opcion1 = Funciones.PedirEntero();
                while (opcion1 < 0 && opcion1 > menuOptions)
                {
                    Console.WriteLine("Lo siento, el valor introducino no corresponde con ninguna opción, vuelva a intentarlo");
                    opcion1 = Funciones.PedirEntero();
                }
                switch (opcion1)
                {
                    case 0:
                        Console.WriteLine("Adiós...");
                        break;
                    case 1:
                        Console.Clear();
                        Console.WriteLine("---   Añadir Contacto   ---");
                        Console.WriteLine("\nIntroduce el nombre del contacto:");
                        string nombre = Funciones.PedirNombre();
                        bool repetido = false;
                        listaContactos.ForEach(contacto => { if (contacto.GetNombre() == nombre) repetido = true; });
                        if (!repetido)
                        {
                            Console.WriteLine("Introduce el nombre del Grupo:");
                            string grupo = Funciones.PedirNombre();
                            Console.WriteLine("Introduce el número de telefono:");
                            int numero = Funciones.PedirEntero();
                            while (!Funciones.ComprobarNumero(numero))
                            {
                                numero = Funciones.PedirEntero();
                            }
                            Contacto nuevoContacto = new Contacto(nombre, grupo, numero);
                            listaContactos.Add(nuevoContacto);
                            Console.WriteLine("Nuevo Contacto Añadido");
                        }
                        else
                            Console.WriteLine("Lo siento, el contacto ya existe un contacto con ese mismo nombre.");
                        Funciones.VolverAlMenu();
                        break;
                    case 2:
                        Console.WriteLine("---   Mover Contacto a memoria   ---");
                        Console.WriteLine("\nIntroduce el nombre del contacto que deseas desplazar:");
                        string desplazado1 = Funciones.PedirNombre();
                        Contacto aDesplazar = new Contacto();
                        aDesplazar = listaContactos.Find(contacto => contacto.GetNombre() == desplazado1);
                        if (aDesplazar != null)
                        {
                            if (aDesplazar.GetAlmacenamiento() == "SIM")
                            {
                                aDesplazar.SetAlmacenamiento("Memoria");
                                Console.WriteLine("Contacto desplazado con éxito.");
                            }
                            else
                            {
                                Console.WriteLine("Lo siento, el Contacto ya se encuentra almacenado en la Memoria del teléfono");
                            }
                        }
                        else
                            Console.WriteLine("Lo siento, el contacto no se encuentra registrado y no puede ser modificado...");

                        Funciones.VolverAlMenu();
                        break;
                    case 3:
                        Console.WriteLine("---   Mover Contacto a SIM   ---");
                        Console.WriteLine("\nIntroduce el nombre del contacto que deseas desplazar:");
                        string desplazado2 = Funciones.PedirNombre();
                        Contacto aDesplazar2 = new Contacto();
                        aDesplazar2 = listaContactos.Find(contacto => contacto.GetNombre() == desplazado2);
                        if (aDesplazar2 != null)
                        {
                            if (aDesplazar2.GetAlmacenamiento() == "Memoria")
                            {
                                aDesplazar2.SetAlmacenamiento("SIM");
                                Console.WriteLine("Contacto desplazado con éxito.");
                            }
                            else
                            {
                                Console.WriteLine("Lo siento, el Contacto ya se encuentra almacenado en la tarjeta SIM del teléfono");
                            }
                        }
                        else
                            Console.WriteLine("Lo siento, el contacto no se encuentra registrado y no puede ser modificado...");
                        Funciones.VolverAlMenu();
                        break;
                    case 4:
                        Console.WriteLine("---   Modificar Grupo   ---");
                        Console.WriteLine("\nIntroduce el nombre del contacto del que deseas modificar el gruopo:");
                        string cambioGrupo = Funciones.PedirNombre();

                        Contacto aCambiarGrupo = listaContactos.Find(contacto => contacto.GetNombre() == cambioGrupo);
                        if (aCambiarGrupo != null)
                        {
                            if (aCambiarGrupo.GetAlmacenamiento() != "SIM")
                            {
                                Console.WriteLine("Introduce el nuevo nombre del grupo:");
                                string nuevoGrupo = Funciones.PedirNombre();
                                aCambiarGrupo.SetGrupo(nuevoGrupo);
                                Console.WriteLine("Grupo modificado correctamente.");
                            }
                            else
                                Console.WriteLine("Lo siento, el contacto ya se encuentra en la tarjeta SIM.");
                        }
                        else
                            Console.WriteLine("Lo siento, el contacto no se encuentra registrado y no puede ser modificado...");
                        Funciones.VolverAlMenu();
                        break;
                    case 5:
                        Console.WriteLine("---   Modificar Teléfono   ---");
                        Console.WriteLine("Introduce el nombre del Contacto del que deseas modificar el número de teléfono");
                        string aCambiarNum = Funciones.PedirNombre();
                        Contacto cambioNum = listaContactos.Find(contacto => contacto.GetNombre() == aCambiarNum);
                        if (cambioNum != null)
                        {
                            if (cambioNum.GetAlmacenamiento() != "SIM")
                            {
                                Console.WriteLine("Introduce el nuevo número:");
                                int nuevoNum = Funciones.PedirEntero();
                                while (!Funciones.ComprobarNumero(nuevoNum))
                                {
                                    nuevoNum = Funciones.PedirEntero();
                                }
                                cambioNum.SetNumero(nuevoNum);
                                Console.WriteLine("Número de teléfono modificado correctamente.");
                            }
                            else
                                Console.WriteLine("Lo siento, el contacto no se encuentra registrado y no puede ser modificado...");
                        }
                        else
                            Console.WriteLine("Lo siento, el nombre introducido no se encuentra en la lista de contactos...");
                        Funciones.VolverAlMenu();
                        break;
                    case 6:
                        Console.WriteLine("---   Mostrar Contactos de SIM   ---\n");
                        listaContactos.ForEach(contacto => { if (contacto.GetAlmacenamiento() == "SIM") Console.WriteLine(contacto.ToString()); });
                        Funciones.VolverAlMenu();
                        break;
                    case 7:
                        Console.WriteLine("---   Mostrar Contactos de memoria   ---");
                        listaContactos.ForEach(contacto => { if (contacto.GetAlmacenamiento() == "Memoria") Console.WriteLine(contacto.ToString()); });
                        Funciones.VolverAlMenu();
                        break;
                }
            } while (opcion1 != 0);
        }
    }
}