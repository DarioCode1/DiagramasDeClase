﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio2_Apartado3
{
    internal class Funciones
    {
        public static void MostrarMenu()
        {
            Console.Clear();
            Console.WriteLine("--------------------------------------------");
            Console.WriteLine("-------      Agenda de Contactos      -------");
            Console.WriteLine("--------------------------------------------");
            Console.WriteLine("\n-<< Seleccione una opción >>-");
            Console.WriteLine("\n1.- Añadir Contacto");
            Console.WriteLine("2.- Mover Contacto a Memoria");
            Console.WriteLine("3.- Mover Contacto a SIM");
            Console.WriteLine("4.- Modificar Gurpo");
            Console.WriteLine("5.- Modificar Teléfono");
            Console.WriteLine("6.- Mostrar Contactos de SIM");
            Console.WriteLine("7.- Mostrar Contactos de Memoria");
            Console.WriteLine("--------------------------------------------");
            Console.WriteLine("\n0.- Salir...");

        }

        public static void VolverAlMenu()
        {
            Console.WriteLine("\nPulse una tecla para ir al menú...");
            Console.ReadKey();
        }
        public static int PedirEntero()
        {
            int res = 0;
            while (!int.TryParse(Console.ReadLine(), out res) && res > 0)
            {
                Console.WriteLine("Lo siento, el número debe de ser entero");
            }
            return res;

        }
        public static bool ComprobarNumero(int numero)
        {
            while (numero.ToString().Length != 9)
            {
                Console.WriteLine("Lo siento, el número debe de estar formado por 9 dígitos, vuelva a introducir el número:");
                numero = Funciones.PedirEntero();
            }
            while ((numero.ToString().Substring(0, 1) != Convert.ToString(9) && numero.ToString().Substring(0, 1) != Convert.ToString(8) && numero.ToString().Substring(0, 1) != Convert.ToString(6)))
            {
                Console.WriteLine("Lo siento, el teléfono debe de comenzar por 6, 8 ó 9, vuelva a introducir el número:");
                numero = Funciones.PedirEntero();
            }
            return true;

        }
        public static string PedirNombre()
        {
            string nombre = Console.ReadLine();
            while (String.IsNullOrEmpty(nombre))
            {
                Console.WriteLine("Lo siento, el nombre no puede quedar vacío, vuelva a probar...");
                nombre = Console.ReadLine();
            }
            return nombre;
        }

    }
}
