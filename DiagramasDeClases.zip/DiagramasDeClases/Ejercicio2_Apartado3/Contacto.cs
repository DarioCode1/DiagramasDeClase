﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio2_Apartado3
{
    internal class Contacto
    {
        private string Nombre { get; set; }
        private string Grupo { get; set; }
        private int Numero { get; set; }
        private string Almacenamiento { get; set; }

        public Contacto()
        {

        }
        public Contacto(string nombre, string grupo, int numero)
        {
            Nombre = nombre;
            Grupo = grupo;
            Numero = numero;
            Almacenamiento = "SIM";
        }
        public override string ToString()
        {
            return $"Nombre:  {Nombre}  |   Grupo:  {Grupo}     |    Numero:  {Numero}      |   Almacenamiento: {Almacenamiento}";
        }

        public string GetNombre()
        {
            return Nombre;
        }
        public void SetNombre(string nombre)
        {
            while (String.IsNullOrEmpty(nombre))
            {
                nombre = Funciones.PedirNombre();
            }
            Nombre = nombre;
        }
        public string GetGrupo()
        {
            return Grupo;
        }
        public void SetGrupo(string grupo)
        {
            Grupo = grupo;
        }
        public int GetNumero()
        {
            return Numero;
        }
        public void SetNumero(int numero)
        {
            if (numero.ToString().Length == 9 || numero.ToString().Substring(0, 1) == Convert.ToString(9) || numero.ToString().Substring(0, 1) == Convert.ToString(8) || numero.ToString().Substring(0, 1) == Convert.ToString(6))
                Numero = numero;
            else
                Numero = 0;
        }
        public string GetAlmacenamiento()
        {
            return Almacenamiento;
        }
        public void SetAlmacenamiento(string almacenamiento)
        {
            while (almacenamiento != "SIM" && almacenamiento != "Memoria")
                almacenamiento = Funciones.PedirNombre();
            Almacenamiento = almacenamiento;

        }
    }
}
