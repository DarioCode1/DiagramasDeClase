﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ejercicio1_Apartado2
{
    public class Vehiculo
    {
        private int velocidad
        {
            get => default;
            set
            {
            }
        }

        private int velocidadMaxima
        {
            get => default;
            set
            {
            }
        }

        public JugadorAvanzado JugadorAvanzado
        {
            get => default;
            set
            {
            }
        }

        public void setVelocidad()
        {
            throw new System.NotImplementedException();
        }

        public int getVelocidad()
        {
            throw new System.NotImplementedException();
        }
    }
}