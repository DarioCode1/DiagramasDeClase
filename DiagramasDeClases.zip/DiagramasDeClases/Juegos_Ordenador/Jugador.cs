﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ejercicio1_Apartado2
{
    public class Jugador
    {
        private string nombre
        {
            get => default;
            set
            {
            }
        }

        private int vidas
        {
            get => default;
            set
            {
            }
        }

        private int x
        {
            get => default;
            set
            {
            }
        }

        private int y
        {
            get => default;
            set
            {
            }
        }

        public void andar()
        {
            throw new System.NotImplementedException();
        }
    }
}