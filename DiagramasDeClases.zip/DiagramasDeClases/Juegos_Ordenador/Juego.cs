﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Juegos_Ordenador
{
    public class Juego
    {
        private string genero
        {
            get => default;
            set
            {
            }
        }

        private int restriccionEdad
        {
            get => default;
            set
            {
            }
        }

        public void Getgenero()
        {
            throw new System.NotImplementedException();
        }

        public void Setgenero()
        {
            throw new System.NotImplementedException();
        }

        public void ObtenerJuego()
        {
            throw new System.NotImplementedException();
        }

        public override string ToString()
        {
            return "Mis heuvos";
        }
    }
}