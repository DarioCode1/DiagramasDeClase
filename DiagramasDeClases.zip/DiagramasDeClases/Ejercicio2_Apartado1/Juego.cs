﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio2_Apartado1
{
    internal class Juego
    {
        private string Nombre { get; set; }
        private decimal Precio { get; set; }
        private List<int> Historial { get; set; }
        private decimal Ganancia { get; set; }
        private bool Estado { get; set; }

        internal Tienda Tienda
        {
            get => default;
            set
            {
            }
        }

        //CONSTR.
        public Juego() { }
        public Juego(string nombre, decimal precio)
        {
            Nombre = nombre;
            Precio = precio;
            Historial = new List<int>();
            Ganancia = 0;
        }

        //FUNCIONES DE JUEGO
        public override string ToString()
        {
            return $"Nombre Juego: {Nombre}    |    Precio:    {Precio}";
        }

        //GETTERS  &&  SETTERS
        public string GetNombre()
        {
            return Nombre;
        }
        public void SetNombre(string nombre)
        {
            Nombre = nombre;
        }
        public decimal GetPrecio()
        {
            return Precio;
        }
        public void SetPrecio(decimal precio)
        {
            Precio = precio;
        }
        public List<int> GetHistorial()
        {
            return Historial;
        }
        public void SetHistorial(List<int> historial)
        {
            Historial = historial;
        }
        public decimal GetGanancia()
        {
            return Ganancia;
        }
        public void SetGanancia(decimal ganancia)
        {
            Ganancia += ganancia;
        }
    }
}

