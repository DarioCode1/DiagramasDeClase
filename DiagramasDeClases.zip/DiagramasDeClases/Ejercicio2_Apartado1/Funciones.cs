﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio2_Apartado1
{
    internal class Funciones
    {
        public static void MostrarMenu()
        {
            Console.Clear();
            Console.WriteLine("-------       MENÚ       -------");
            Console.WriteLine("-<< Seleccione una opción >>-");
            Console.WriteLine("1.- Alquilar Juego");
            Console.WriteLine("2.- Devolver Juego");
            Console.WriteLine("3.- Ver Info actual tienda");
            Console.WriteLine("4.- Mostrar historial por juego");
            Console.WriteLine("\n0.- SALIR");

        }
        public static void VolverAlMenu()
        {
            Console.WriteLine("\nPulse una tecla para volver al menú...");
            Console.ReadKey();
        }
        public static int PedirEntero(int min, int max)
        {
            int res = 0;
            while (!int.TryParse(Console.ReadLine(), out res))
            {
                Console.WriteLine("Lo siento, el número debe de ser entero");
            }
            return res;

        }
        public static decimal PedirDecimal()
        {
            decimal res = 0;
            while (!decimal.TryParse(Console.ReadLine(), out res) | res < 0)
            {
                Console.WriteLine("Lo siento, el dato introducido debe de ser una cifra positiva, vuelve a probar...");
            }
            return res;

        }
    }
}
