﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio2_Apartado1
{
    internal class Tienda
    {
        private string Encargado { get; set; }
        private int Telefono { get; set; }
        private List<Juego> Catalogo { get; set; }
        private List<Juego> Alquilados { get; set; }

        //CONSTRUCTORES
        public Tienda() { }
        public Tienda(string encargado, int telefono, List<Juego> catalogo)
        {
            Encargado = encargado;
            Telefono = telefono;
            Catalogo = catalogo;
            Alquilados = new List<Juego>();
        }

        //FUNCIONES
        public void AlquilarJuego(int optAlq, int usuario)
        {
            bool salir = false;
            for (int i = 0; i < Alquilados.Count; i++)
            {
                if (Alquilados[i].GetHistorial()[Alquilados[i].GetHistorial().Count - 1] == usuario && !salir)
                {
                    Console.WriteLine("¡Alerta! El usuario ya tiene un juego alquilado.");
                    salir = true;
                }
            }
            if (!salir)
            {
                Alquilados.Add(Catalogo[optAlq - 1]);
                List<int> listaUsuarios = new List<int>();
                listaUsuarios = Catalogo[optAlq - 1].GetHistorial();
                listaUsuarios.Add(usuario);
                Catalogo[optAlq - 1].SetHistorial(listaUsuarios);
                Catalogo.RemoveAt(optAlq - 1);
                Console.WriteLine("¡Juego alquilado!");
            }
            Funciones.VolverAlMenu();

        }
        public void DevolverJuego(int optAlq1)
        {
            Juego devuelto = Alquilados.Find(juego => juego.GetHistorial()[juego.GetHistorial().Count - 1] == optAlq1);
            devuelto.SetGanancia(devuelto.GetPrecio());
            Catalogo.Add(devuelto);
            Alquilados.Remove(devuelto);
        }

        public void MostrarInfo()
        {
            Console.WriteLine("---   INFO TIENDA   ---");
            Console.WriteLine($"Encargado:  {Encargado}\nTelefono Tienda:   {Telefono}\n\n");
            Console.WriteLine("Juegos disponibles:");
            Catalogo.ForEach(juego => Console.WriteLine(juego.ToString()));
            Console.WriteLine("\nJuegos alquilados actualmente:");
            Alquilados.ForEach(juego => Console.WriteLine(juego.ToString()));
        }

        //GETTERS && SETTERS
        public string GetEncargado()
        {
            return Encargado;
        }
        public void SetEncargado(string encargado)
        {
            Encargado = encargado;
        }
        public int GetTelefono()
        {
            return Telefono;
        }
        public void SetTelefono(int telefono)
        {
            Telefono = telefono;
        }
        public List<Juego> GetCatalogo()
        {
            return Catalogo;
        }
        public void SetCatalogo(List<Juego> catalogo)
        {
            Catalogo = catalogo;
        }
        public List<Juego> GetAlquilados()
        {
            return Alquilados;
        }
        public void SetAlquilados(List<Juego> alquilados)
        {
            Alquilados = alquilados;
        }

    }
}

