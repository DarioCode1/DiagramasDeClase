﻿namespace Ejercicio2_Apartado1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<Juego> listaJuegos = new List<Juego>() { new Juego("Harry Petas",29.95m),new Juego("Cool Boarders",24.50m),new Juego("Tony Hawk's",27.75m),
            new Juego("South Park Rally", 36.66m),new Juego("GTA V",40m)};
            Console.WriteLine("----    BIENVENIDO    ----");
            Console.WriteLine("Quieres crear una nueva tienda?");
            Console.WriteLine("1.- SÍ");
            Console.WriteLine("2.- NO, salir...");
            int ini = 0;
            ini = Funciones.PedirEntero(1, 2);
            if (ini == 2)
                Console.WriteLine("¡Hasta la próxima!");
            else
            {
                Console.WriteLine("Introduce el nombre del propietario:");
                string nombre = Console.ReadLine();
                while (String.IsNullOrEmpty(nombre) | nombre.Length < 3)
                {
                    Console.WriteLine("Lo siento el nombre no puede quedar vacío y no puede tener menos de 3 letras, vulelve a probar:");
                    nombre = Console.ReadLine();
                }
                Console.WriteLine("Introduce el número de teléfono:");
                string telefono = Console.ReadLine();
                int valid = 0;
                while (telefono.Substring(0, 3) != "922" | !int.TryParse(telefono, out valid) | telefono.Length != 9)
                {
                    Console.WriteLine("El número debe de comenzar por 922 y debe tener 9 cifras. Vuelve a probar");
                    telefono = Console.ReadLine();
                }
                Tienda tienda = new Tienda(nombre, valid, listaJuegos);

                int opt1 = 0;
                do
                {
                    Funciones.MostrarMenu();
                    opt1 = Funciones.PedirEntero(0, 4);
                    switch (opt1)
                    {
                        case 0:
                            Console.WriteLine("!Adiós!");
                            break;
                        case 1:
                            Console.WriteLine("---   Alquilar Juego   ---");
                            int contAlq = 1;
                            tienda.GetCatalogo().ForEach(juego => Console.WriteLine(contAlq++ + ".- " + juego.ToString()));
                            Console.WriteLine("\nIntroduce el número del juego que deseas alquilar:");
                            int optAlq = Funciones.PedirEntero(1, tienda.GetCatalogo().Count);
                            Console.WriteLine("\n Introduce el número de usuario:");
                            int usuario = Funciones.PedirEntero(100, 999);
                            tienda.AlquilarJuego(optAlq, usuario);

                            break;
                        case 2:
                            Console.WriteLine("---   Devolver Juego   ---");
                            if (tienda.GetAlquilados().Count > 0)
                            {
                                int contAlq1 = 1;
                                tienda.GetAlquilados().ForEach(juego => Console.WriteLine(contAlq1++ + ".- " + juego.ToString()));
                                Console.WriteLine("\n Teclea el número de usuario:");
                                tienda.GetAlquilados().ForEach(juego => Console.WriteLine(juego.GetHistorial()[juego.GetHistorial().Count - 1]));
                                int optAlq1 = Funciones.PedirEntero(100, 999);
                                bool esta = false;

                                for (int i = 0; i < tienda.GetAlquilados().Count; i++)
                                {
                                    if (optAlq1 == tienda.GetAlquilados()[i].GetHistorial()[tienda.GetAlquilados()[i].GetHistorial().Count - 1])
                                    {
                                        esta = true;
                                    }
                                }
                                if (esta)
                                {
                                    tienda.DevolverJuego(optAlq1);
                                    Console.WriteLine("¡Juego Devuelto!");
                                }
                                else
                                    Console.WriteLine("Lo siento, no hay ningún usuario registrado con ese número.");
                            }
                            else
                                Console.WriteLine("Lo siento, no hay ningún juego alquilado en eestos momentos.");
                            Funciones.VolverAlMenu();
                            break;
                        case 3:
                            Console.WriteLine("---   INFO Tienda   ---");
                            tienda.MostrarInfo();
                            Funciones.VolverAlMenu();
                            break;
                        case 4:
                            Console.WriteLine("Seleccione el juego del que desea ver el historial");
                            List<Juego> listaCompleta = new List<Juego>();
                            tienda.GetAlquilados().ForEach(juego => listaCompleta.Add(juego));
                            tienda.GetCatalogo().ForEach(juego => listaCompleta.Add(juego));
                            int contH = 1;
                            listaCompleta.ForEach(juego => Console.WriteLine(contH++ + ".- " + juego.ToString()));
                            int optH = Funciones.PedirEntero(1, 5);
                            Console.Clear();
                            Console.WriteLine("----------         HISTORIAL JUEGO          ----------\n\n");
                            Console.WriteLine(listaCompleta[optH - 1].ToString());
                            Console.WriteLine("Ganancias totales:   " + listaCompleta[optH - 1].GetGanancia());
                            Console.WriteLine("Historial de usuarios:");
                            listaCompleta[optH - 1].GetHistorial().ForEach(usuario => Console.Write(usuario + ", "));
                            Funciones.VolverAlMenu();

                            break;
                    }
                } while (opt1 != 0);
            }
        }
    }
}