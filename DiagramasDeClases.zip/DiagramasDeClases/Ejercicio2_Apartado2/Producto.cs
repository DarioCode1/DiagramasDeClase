﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio2_Apartado2
{
    internal class Producto
    {
        private string Nombre { get; set; }
        private decimal Precio { get; set; }

        internal Factura Factura
        {
            get => default;
            set
            {
            }
        }

        public Producto()
        {

        }
        public Producto(string nombre, decimal precio)
        {
            Nombre = nombre;
            if (precio <= 0)
                Precio = precio;
            else
                Precio = 0;
        }
        public string PedirNombre()
        {
            string nombre = "";
            nombre = Console.ReadLine();
            while (String.IsNullOrEmpty(nombre))
            {
                Console.WriteLine("Lo siento, el nombre no puede quedar vacío, vuelva a probar:");
                nombre = Console.ReadLine();
            }
            return nombre;
        }
        public decimal PedirPrecio()
        {
            decimal precio = 0;
            while (!decimal.TryParse(Console.ReadLine(), out precio) || precio < 0)
                Console.WriteLine("Lo siento, el precio debe ser un valor numérico positivo, vuelva a intentarlo:");
            return precio;
        }

        public string GetNombre()
        {
            return Nombre;
        }
        public void SetNombre(string nombre)
        {
            Nombre = nombre;
        }
        public decimal GetPrecio()
        {
            return Precio;
        }
        public void SetPrecio(decimal precio)
        {
            Precio = precio;
        }
    }
}
