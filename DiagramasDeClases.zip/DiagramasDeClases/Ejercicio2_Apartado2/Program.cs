﻿namespace Ejercicio2_Apartado2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Factura factura = new Factura();
            List<decimal> preciosIniciales = new List<decimal>();
            List<decimal> preciosFinales = new List<decimal>();
            Console.WriteLine("Introduce los distintos productos de tu cesta de la compra para calcular" +
                " el precio de tu factura una vez apliquemos los descuentos oportunos.");
            bool continuar = false;
            int cont = 1;
            do
            {
                string nombre = "";
                decimal precio = 0;
                Producto producto = new Producto();
                Console.WriteLine($"Introduce el nombre del producto nº {cont++}");
                nombre = producto.PedirNombre();
                producto.SetNombre(nombre);
                Console.WriteLine("Introduce el precio del producto");
                precio = producto.PedirPrecio();
                producto.SetPrecio(precio);
                factura.GetCompra().Add(producto);
                Console.WriteLine("Producto añadido a la factura. \n¿Hay más productos que añadir a la factura?\n" +
                    "1.- SÍ\n2.- NO");
            } while (factura.PedirContinuar());

            factura.GetCompra().ForEach(producto => preciosIniciales.Add(producto.GetPrecio()));
            factura.DescontarProductos();
            factura.GetCompra().ForEach(producto => preciosFinales.Add(producto.GetPrecio()));
            Console.WriteLine("---   Factura---\n");
            Console.WriteLine("Prreoductos adquiridos:");
            int cont2 = 0;
            factura.GetCompra().ForEach(product => Console.WriteLine(product.GetNombre() + "      |    precio Inicial:    " + preciosIniciales[cont2] + "      |     Precio Final:    " + preciosFinales[cont2++]));
            decimal precioFactura = factura.CalcularFactura();
            Console.WriteLine("\nPRECIO FINAL:  " + precioFactura);


        }
    }
}