﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio2_Apartado2
{
    internal class Factura
    {
        private List<Producto> Compra;
        public Factura()
        {
            Compra = new List<Producto>();
        }
        public Factura(List<Producto> compra)
        {
            Compra = compra;
        }
        public bool PedirContinuar()
        {
            int eleccion = 0;
            while (!int.TryParse(Console.ReadLine(), out eleccion) && eleccion != 1 && eleccion != 2)
            {
                Console.WriteLine("Lo siento, la opción escogida no corresponde con ninguna acción. Presione 1 o 2 y pulse enter:");
            }
            if (eleccion == 1)
                return true;
            else
                return false;
        }
        public void DescontarProductos()
        {
            int productosRegalados = Compra.Count / 3;
            if (productosRegalados > 0)
            {
                while (productosRegalados > 0)
                {
                    List<decimal> precios = new List<decimal>();
                    Producto productoMasBarato = new Producto();
                    Compra.ForEach(producto => { if (producto.GetPrecio() > 0) precios.Add(producto.GetPrecio()); });
                    productosRegalados--;
                    productoMasBarato = Compra.Find(producto => producto.GetPrecio() == precios.Min());
                    productoMasBarato.SetPrecio(0);
                }

            }
        }
        public decimal CalcularFactura()
        {
            decimal precioTotal = 0;
            Compra.ForEach(producto => precioTotal += producto.GetPrecio());
            return precioTotal;
        }
        public List<Producto> GetCompra()
        {
            return Compra;
        }
        public void SetCompra(List<Producto> compra)
        {
            Compra = compra;
        }
    }
}
