﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AstrofisicoTenerife
{
    public class Suscriptor
    {
        public Publicador Publicador
        {
            get => default;
            set
            {
            }
        }

        public void actualizar()
        {
            throw new System.NotImplementedException();
        }
    }
}