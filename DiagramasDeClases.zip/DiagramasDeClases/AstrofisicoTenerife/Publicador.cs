﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AstrofisicoTenerife
{
    public class Publicador : Satelite
    {
        public Suscriptor ListaSuscriptores
        {
            get => default;
            set
            {
            }
        }

        public void notificar()
        {
            throw new System.NotImplementedException();
        }

        public void permitirSuscripcion()
        {
            throw new System.NotImplementedException();
        }

        public void darBaja()
        {
            throw new System.NotImplementedException();
        }
    }
}