﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AstrofisicoTenerife
{
    public class CuerpoSolido
    {
        private string imagen
        {
            get => default;
            set
            {
            }
        }

        private string direccion
        {
            get => default;
            set
            {
            }
        }

        private int posicion
        {
            get => default;
            set
            {
            }
        }

        private int velocidad
        {
            get => default;
            set
            {
            }
        }
    }
}