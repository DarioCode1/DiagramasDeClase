﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AstrofisicoTenerife
{
    public class PanelInstrumentos
    {
        public Instrumento Instrumento
        {
            get => default;
            set
            {
            }
        }

        public void activar()
        {
            throw new System.NotImplementedException();
        }

        public void desactivar()
        {
            throw new System.NotImplementedException();
        }

        public void visualizar()
        {
            throw new System.NotImplementedException();
        }
    }
}