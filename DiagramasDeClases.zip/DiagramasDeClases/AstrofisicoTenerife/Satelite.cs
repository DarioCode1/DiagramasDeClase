﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AstrofisicoTenerife
{
    public class Satelite : CuerpoSolido
    {
        public void aumentar()
        {
            throw new System.NotImplementedException();
        }

        public void disminuir()
        {
            throw new System.NotImplementedException();
        }

        public void girarIzquierda()
        {
            throw new System.NotImplementedException();
        }

        public void girarDerecha()
        {
            throw new System.NotImplementedException();
        }

        public void apagar()
        {
            throw new System.NotImplementedException();
        }
    }
}