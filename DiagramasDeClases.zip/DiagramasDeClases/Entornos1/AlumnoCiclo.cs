﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Matriculacion_Instituto
{
    public class AlumnoCiclo
    {
        public string grado
        {
            get => default;
            set
            {
            }
        }

        public string curso
        {
            get => default;
            set
            {
            }
        }

        public string modalidad
        {
            get => default;
            set
            {
            }
        }

        public Alumno Alumno
        {
            get => default;
            set
            {
            }
        }
    }
}