﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Matriculacion_Instituto
{
    public class AlumnoFPBasica
    {
        public string nombrePadre
        {
            get => default;
            set
            {
            }
        }

        public string nombreMadre
        {
            get => default;
            set
            {
            }
        }

        public Alumno Alumno
        {
            get => default;
            set
            {
            }
        }
    }
}