﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Matriculacion_Instituto
{
    public class Curso
    {
        private int contadorAlumnos
        {
            get => default;
            set
            {
            }
        }

        private int contadorProfesores
        {
            get => default;
            set
            {
            }
        }

        public Profesor Profesor
        {
            get => default;
            set
            {
            }
        }

        public Alumno Alumno
        {
            get => default;
            set
            {
            }
        }

        public void matricular()
        {
            throw new System.NotImplementedException();
        }

        public void desmatricular()
        {
            throw new System.NotImplementedException();
        }
    }
}