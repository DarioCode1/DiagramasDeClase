﻿namespace Ejercicio1_Apartado1
{
    internal class Program
    {
        static void Main(string[] args)
        { }
    }
}