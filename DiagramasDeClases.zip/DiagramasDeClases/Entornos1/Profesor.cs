﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Matriculacion_Instituto
{
    public class Profesor : Persona
    {
        private string asignatura
        {
            get => default;
            set
            {
            }
        }
    }
}