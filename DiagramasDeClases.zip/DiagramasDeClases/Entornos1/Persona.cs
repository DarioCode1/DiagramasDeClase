﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Matriculacion_Instituto
{
    public class Persona
    {
        private Date nacimiento
        {
            get => default;
            set
            {
            }
        }

        private string nombre
        {
            get => default;
            set
            {
            }
        }

        private string apellidos
        {
            get => default;
            set
            {
            }
        }
    }
}